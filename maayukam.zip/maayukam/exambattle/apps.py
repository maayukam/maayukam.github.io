from django.apps import AppConfig


class ExambattleConfig(AppConfig):
    name = 'exambattle'
